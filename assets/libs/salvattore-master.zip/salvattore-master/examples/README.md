# How to run
Run a HTTP server in the root folder, where `salvattore.js` or `.min.js` are and then go to http://localhost:8000/examples/timeline.html

The easiest way to run a HTTP server is by using the `python -m SimpleHTTPServer` command.
